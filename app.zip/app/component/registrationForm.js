import React,{Component}  from 'react';
import {
    StyleSheet,
    Text,
    View,
    SafeAreaView,
    TouchableOpacity,
    Dimensions,
    Modal,
    Image,
    Animated,
    PermissionsAndroid,
    ImageEditor,
    Platform
} from 'react-native';

import Constant from './../helper/constant';
import FloatingLabel from 'react-native-floating-labels';
//import {connect} from 'react-redux';
//import { userRegistration } from "../Actions/userActions";
//import { NavigationActions, StackActions } from 'react-navigation';
import Camera from "react-native-camera";
import Icon from 'react-native-vector-icons/FontAwesome'
import IconM from 'react-native-vector-icons/MaterialIcons'
import IconA from 'react-native-vector-icons/AntDesign'

let { height, width } = Dimensions.get('window');
let orientation = height > width ? 'Portrait' : 'Landscape';
let platform=Platform.OS

const flash = {
   on: {name: 'flash-on', mode: Camera.constants.FlashMode.on},
   off: {name: 'flash-off', mode: Camera.constants.FlashMode.off},
   auto:  {name: 'flash-auto', mode: Camera.constants.FlashMode.auto},
};

export default class RegistrationForm extends Component<Props> {

    constructor(props){
        super(props);
        this.state={
           firstname:"",
            lastname:"",
            modalVisible: false,
            orientation,
            imageUri:null,
            selectedFlash:flash.off,
            drawer:false,
        };
        this.offset = new Animated.Value(0);
    }
    componentWillMount() {
        Dimensions.addEventListener('change', this.handleOrientationChange);
    }
    componentWillUnmount() {
        Dimensions.removeEventListener('change', this.handleOrientationChange);
    }

    handleOrientationChange = dimensions => {
        ({ height, width } = dimensions.window);
        orientation = height > width ? 'Portrait' : 'Landscape';
        this.setState({ orientation });
    };

    takePicture= () =>{
        this.camera.capture().then(data => {

            let offx;
            let offy;

            if (platform==='android') {
                 offx = ((data.width*80) / (Constant.screenWidth));
                 offy=((data.height*60)/(Constant.screenHeight));
            }
            else if(platform==='ios') {
                 offx = ((data.width *60) / (Constant.screenWidth));
                 offy=((data.height*60)/(Constant.screenHeight));
            }
            const cropData = {
                offset: {
                    x: offx,
                    y: offy,
                },
                size: {
                    width: data.width-(offx*2),
                    height: data.height-(offy*2),
                },
                resizeMode: 'contain'
            };
            ImageEditor.cropImage(
                data.path,
                cropData,
                (successURI) => {
                    debugger
                    this.setState({imageUri:successURI,modalVisible:false})
                    this.props.navigation.navigate('ViewImage',{imageUri:successURI})
                  //  alert(successURI);
                },
                (error) => {
                    console.log("Error cropping Image: ", error)
                    alert(error.message);
                },
            );

        })
            .catch(err => {
                console.log("Error capturing Image: ", error)
                alert(err)
                this.setState({modalVisible:false})
            });
    }
    startAnimateView = () => {
            Animated.timing(this.offset, {
                duration: 500,
                toValue: parseInt(Constant.screenHeight/7),
            }).start(()=>{
                this.setState({drawer:true})
            });
    };
    stopAnimateView = () => {
        Animated.timing(this.offset, {
            duration: 500,
            toValue: parseInt(0),
        }).start(()=>{
            this.setState({drawer:false})
        });
    };
    requestPermission=async()=> {
        try {
            const grantedcamera = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.CAMERA,
                // {
                //     title: 'Camera Permission',
                //     message:
                //         'This App needs access to your camera so you can take awesome pictures.',
                //     buttonNeutral: 'Ask Me Later',
                //     buttonNegative: 'Cancel',
                //     buttonPositive: 'OK',
                // },
            );
            //alert(JSON.stringify(grantedcamera))
            const grantedreadstorage = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
            );

            const grantedwritestorage = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,

            );
                if (grantedcamera === PermissionsAndroid.RESULTS.GRANTED &&
                    grantedreadstorage === PermissionsAndroid.RESULTS.GRANTED
                    && grantedwritestorage === PermissionsAndroid.RESULTS.GRANTED)
                 {
                     this.setState({modalVisible:true})
                } else {
                    alert('permission not granted')
                }
        } catch (err) {
            alert(err);
        }
    }
    render(){
        return(
            <View style={styles.container}>
                    <SafeAreaView style={{flex:1}}>

                        <View style={styles.headerView}>
                            <Text style={styles.headerText}>
                                Bronze Financial
                            </Text>
                            <IconM name={"menu"} size={30} style={styles.menuIcon} onPress={
                                this.state.drawer?this.stopAnimateView:this.startAnimateView
                            }/>
                        </View>
                        <View style={{flex:9}} >
                            <Animated.View style={{backgroundColor:Constant.blackcolor,height:this.offset,overflow:'hidden' }}>

                                  <View style={{flexDirection:'row',marginTop:10,backgroundColor:Constant.whiteColor,borderWidth:5, borderColor:Constant.graycolor,
                                  width:(Constant.screenWidth/5)*4,padding:5,marginLeft:10}}>
                                      <Text style={{color:Constant.blackcolor,fontSize:Constant.fontSize.small}}>
                                          82jmeghna+test1@gmail.com
                                      </Text>

                                      {/*<Image source={require('')} style={{height:'100%',width:'100%'}}/>*/}
                                      {/*<Icon name={"sort-down"} size={20}  />*/}
                              </View>

                            </Animated.View>
                            <View style={styles.mainView} >
                                <View style={styles.topView}>
                                    <Icon name={"user"} size={30} style={styles.iconstyle} />
                                    <FloatingLabel
                                        autoCapitalize = "none"
                                        labelStyle={styles.lablestyle}
                                        inputStyle={styles.textstyle}
                                        style={styles.textinput}
                                        onChangeText={(firstname) => this.setState({firstname})}>FirstName</FloatingLabel>
                                </View>
                                <View style={styles.topView}>
                                    <Icon name={"user"} size={30} style={styles.iconstyle} />
                                    <FloatingLabel
                                        autoCapitalize = "none"
                                        labelStyle={styles.lablestyle}
                                        inputStyle={styles.textstyle}
                                        style={styles.textinput}
                                        onChangeText={(lastname) => this.setState({lastname})}>LastName</FloatingLabel>
                                </View>
                                <View style={{flexDirection: 'row',marginTop: 20,}}>
                                <TouchableOpacity
                                  onPress={()=>{
                                  if(platform==='android')
                                      this.requestPermission()
                                  else if(platform==='ios')
                                      this.setState({modalVisible:true})
                                  }
                                  }
                                    style={styles.buttonView}>

                                    <Text style={styles.buttontxt} >Scan ID</Text>

                                </TouchableOpacity>
                                    <TouchableOpacity
                                        style={styles.buttonView}>

                                        <Text style={styles.buttontxt} >Submit</Text>

                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <Modal
                            animationType="slide"
                            transparent={false}
                            visible={this.state.modalVisible}
                            onRequestClose={() => {
                                this.setState({modalVisible:false})
                            }}>
                            <View style={{flex:1}}>
                                <Camera
                                    captureTarget={Camera.constants.CaptureTarget.disk}
                                    ref={cam => {
                                        this.camera = cam;
                                    }}
                                    style={styles.modelcontainer}
                                    aspect={Camera.constants.Aspect.fill}
                                    orientation="auto"
                                    flashMode={this.state.selectedFlash.mode}
                                >
                                </Camera>
                                    <View style={{bottom: 0,top:0,left:0,right:0,position:'absolute',
                                        backgroundColor:'transperent', borderWidth:60,borderColor:'rgba(0,0,0,0.4)'}}>
                                    </View>
                                <View style={{bottom: 0,top:0,left:0,right:0,position:'absolute',
                                    backgroundColor:'transperent'}}>
                                        <View  style={styles.topContainer}>
                                            <TouchableOpacity
                                                onPress={()=>
                                                    this.setState({modalVisible:false})}
                                                style={ styles.buttonPortrait}
                                            >
                                                <Icon name="close" size={25} style={{ color: Constant.bluecolor }}/>
                                            </TouchableOpacity>
                                        </View>
                                    <View style={{bottom: 60,top:60,left:60,right:60,position:'absolute',borderColor:'white',
                                        borderWidth:2, backgroundColor:'transperent',borderStyle: 'dashed' ,borderRadius:5}}>
                                    </View>
                                        <View style={styles.buttonContainerPortrait}>

                                            <TouchableOpacity
                                                onPress={()=> {
                                                    this.takePicture();
                                                }}
                                                style={styles.buttonPortrait}
                                            >
                                                <Icon name="camera" size={25} style={{ color: Constant.bluecolor}} />
                                            </TouchableOpacity>

                                            <TouchableOpacity
                                                onPress={()=>{
                                                    if(this.state.selectedFlash===flash.on){
                                                        this.setState({selectedFlash:flash.off})
                                                    }else if(this.state.selectedFlash===flash.off){
                                                        this.setState({selectedFlash:flash.auto})
                                                    } else if(this.state.selectedFlash===flash.auto){
                                                        this.setState({selectedFlash:flash.on})
                                                    }
                                                }}
                                                style={ styles.buttonPortrait}
                                            >
                                                <IconM name={this.state.selectedFlash.name} size={25}
                                                       style={{ color: Constant.bluecolor }}/>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                            </View>
                        </Modal>

                    </SafeAreaView>

                </View>

        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Constant.whiteColor,
    },
    mainView:{
        paddingHorizontal:15,
        paddingTop: 25
    },
    textinput:{
        borderBottomWidth: 2,
        borderColor:Constant.graycolor,
        flex:6,
    },
    iconstyle:{
        flex:1,
        paddingTop:30,
        color:Constant.graycolor,
    },
    topView:{
        flexDirection: 'row',
        padding: 2,
        borderRadius:10,
        margin: 3,
    },
    imagestyle:{
        marginTop:10,
        padding: 20,
        alignItems: 'center',
    },
    textstyle:{
        borderWidth:0,
        color:Constant.blackcolor,
        fontSize:Constant.fontSize.medium
    },
    lablestyle:{
        color: Constant.graycolor,
        fontSize: Constant.fontSize.small,
        fontWeight:'500'
    },
    buttontxt:{
        color:Constant.whiteColor,
        fontSize:Constant.fontSize.large,
        fontWeight:"500",
        padding:5,
    },
    menuIcon:{
        color:Constant.graycolor,
        justifyContent:'flex-end'
    },
    headerText:{
        color:Constant.whiteColor,
        fontSize:Constant.fontSize.large,
        fontWeight:'bold',
        flex:1
    },
    headerView:{
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:Constant.blackcolor,
        flex:1,
        paddingHorizontal:15,
        flexDirection:'row'
    },
    buttonView:{
        justifyContent: 'center',
        alignItems:'center',
        flex:1,
        padding:5,
        margin:10,
        borderRadius:10,
        backgroundColor: Constant.bluecolor
    },
    modelcontainer: {
        flex: 1,

    },
    buttonContainerPortrait: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'space-between',
    //    backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    topContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'flex-end',
       // backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    topContainerLandscape:{
        //transform: [{ rotate: '90deg'}],
        position: 'absolute',
        top: 25,
        left: 0,
        right: 25,
        flexDirection: 'column',
        justifyContent: 'flex-end',
       // backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    buttonContainerLandscape: {
        transform: [{ rotate: '90deg'}],
    },
    buttonPortrait: {
        backgroundColor: 'transparent',
        margin: 10,
        borderWidth: 2,
        borderRadius:25,
        borderColor: Constant.bluecolor,
        height:50,
        width:50,
        alignItems:'center',
        justifyContent:'center'
    },
    canclePotrait:{
        backgroundColor: 'transparent',
       // marginHorizontal: 10
    },
    buttonLandscape: {
        transform: [{ rotate: '90deg'}],
        padding: 10,
        marginHorizontal: 20,
        borderWidth: 2,
        borderRadius:25,
        borderColor: '#fff'
    }
});

// const mapStateToProps = (state) => {
//     const {loading} = state.user;
//     return {
//         loading
//     };
// };
//
// export default connect(mapStateToProps,{
//     userRegistration
// })(Registration);

