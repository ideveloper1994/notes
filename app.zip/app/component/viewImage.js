import React,{Component}  from 'react';
import {
    StyleSheet,
    Text,
    View,
    SafeAreaView,
    TouchableOpacity,
    Dimensions,
    Modal,
    Image, Animated
} from 'react-native';

import Constant from './../helper/constant';
import FloatingLabel from 'react-native-floating-labels';
//import {connect} from 'react-redux';
//import { userRegistration } from "../Actions/userActions";
//import { NavigationActions, StackActions } from 'react-navigation';
import Camera from "react-native-camera";
import Icon from 'react-native-vector-icons/FontAwesome'
import IconM from 'react-native-vector-icons/MaterialIcons'
import IconA from 'react-native-vector-icons/AntDesign'



let { height, width } = Dimensions.get('window');
let orientation = height > width ? 'Portrait' : 'Landscape';

export default class ViewImage extends Component<Props> {

    constructor(props){
        super(props);
        this.state={
            imageUri:props.navigation.state.params.imageUri,
        };
        this.offset = new Animated.Value(Constant.screenHeight);

    }
    animateView = () => {
        Animated.timing(this.offset, {
            duration: 500,
            toValue: parseInt(Constant.screenHeight/10),
        }).start()
    };
    render(){
        return(
            <View style={styles.container}>
                <SafeAreaView style={{flex:1}}>
                    <View style={styles.headerView}>
                        <Text style={styles.headerText}>
                            Bronze Financial
                        </Text>
                        {/*<IconM name={"menu"} size={30} style={styles.menuIcon} />*/}
                    </View>
                    <View style={styles.mainView} >
                         <Image source={{uri:this.state.imageUri}} style={{height:'100%',width:'100%',flex:1}}
                                resizeMode={'contain'}/>
                        {/*,width: 20, height: 20*/}
                        <TouchableOpacity style={styles.buttonView}
                        onPress={this.animateView}>

                            <Text style={styles.buttontxt} >Submit</Text>
                            <Animated.View style={{backgroundColor:Constant.blackcolor,
                                height:(Constant.screenHeight-(Constant.screenHeight/10)),
                                width:Constant.screenWidth,
                                transform: [{translateY:this.offset}],
                                overflow:'hidden' }}>
                                <Text style={{color:Constant.whiteColor,fontSize:Constant.fontSize.small}}>
                                    82jmeghna+test1@gmail.com
                                </Text>

                                {/*<View style={{flexDirection:'row',marginTop:10,backgroundColor:Constant.whiteColor,borderWidth:5, borderColor:Constant.graycolor,*/}
                                {/*width:(Constant.screenWidth/5)*4,padding:5,marginLeft:10}}>*/}
                                {/*<Text style={{color:Constant.blackcolor,fontSize:Constant.fontSize.small}}>*/}
                                {/*82jmeghna+test1@gmail.com*/}
                                {/*</Text>*/}

                                {/*/!*<Image source={require('')} style={{height:'100%',width:'100%'}}/>*!/*/}
                                {/*/!*<Icon name={"sort-down"} size={20}  />*!/*/}
                                {/*</View>*/}

                            </Animated.View>
                        </TouchableOpacity>

                    </View>
                </SafeAreaView>

            </View>

        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Constant.whiteColor,
    },
    mainView:{
        padding:15,
        flex:9
    },
    textinput:{
        borderBottomWidth: 2,
        borderColor:Constant.graycolor,
        flex:6,
    },
    iconstyle:{
        flex:1,
        paddingTop:30,
        color:Constant.graycolor,
    },
    topView:{
        flexDirection: 'row',
        padding: 2,
        borderRadius:10,
        margin: 3,
    },
    imagestyle:{
        marginTop:10,
        padding: 20,
        alignItems: 'center',
    },
    textstyle:{
        borderWidth:0,
        color:Constant.blackcolor,
        fontSize:Constant.fontSize.medium
    },
    lablestyle:{
        color: Constant.graycolor,
        fontSize: Constant.fontSize.small,
        fontWeight:'500'
    },
    buttonView:{
        justifyContent: 'center',
        alignItems:'center',
        padding:15,
        margin:30,
        borderRadius:20,
        backgroundColor: Constant.bluecolor
    },
    buttontxt:{
        color:Constant.whiteColor,
        fontSize:Constant.fontSize.large,
        fontWeight:"500",
    },
    menuIcon:{
        color:Constant.graycolor,
        justifyContent:'flex-end'
    },
    headerText:{
        color:Constant.whiteColor,
        fontSize:Constant.fontSize.large,
        fontWeight:'bold',
        flex:1
    },
    headerView:{
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:Constant.blackcolor,
        flex:1,
        paddingHorizontal:15,
        flexDirection:'row'
    },

    modelcontainer: {
        flex: 1,
    },
    buttonContainerPortrait: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'space-between',
        //    backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    topContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        // backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    buttonPortrait: {
        backgroundColor: 'transparent',
        padding: 10,
        marginHorizontal: 20,
        borderWidth: 2,
        borderRadius:25,
        borderColor: '#fff'
    },
    canclePotrait:{
        backgroundColor: 'transparent',
        padding: 5,
        marginHorizontal: 10
    }
});


