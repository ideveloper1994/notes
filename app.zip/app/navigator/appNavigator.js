import {createStackNavigator,createAppContainer} from 'react-navigation';
import Register from '../component/registrationForm';
import ViewImage from '../component/viewImage'

const appNavigation=createStackNavigator({
    Register,
    ViewImage
    },
    {
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        },
        initialRouteName:'Register'
    },
);

export default createAppContainer(appNavigation)