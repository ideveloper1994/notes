//
//  Trip.swift
//  tripApp
//
//  Created by mac on 20/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import UIKit
import Firebase

struct Trip {
    
    var name : String
    var startDate : Date
    var endDate : Date
    var tripStatus : String
    
    var dictionary: [String: Any] {
        return [
            "name": name,
            "startDate": startDate,
            "endDate": endDate,
            "tripStatus": tripStatus
        ]
    }
    
}

extension Trip: DocumentSerializable {
    
    init?(dictionary: [String : Any]) {
        guard let name = dictionary["name"] as? String,
            let startDate = dictionary["startDate"] as? Timestamp,
            let endDate = dictionary["endDate"] as? Timestamp,
            let tripStatus = dictionary["tripStatus"] as? String else { return nil }
        
        self.init(name: name, startDate: startDate.dateValue(), endDate: endDate.dateValue(), tripStatus: tripStatus)
    }
    
}
