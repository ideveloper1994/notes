//
//  AddTripViewController.swift
//  tripApp
//
//  Created by mac on 20/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import FirebaseFirestore

class AddTripViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtStartDate: UITextField!
    @IBOutlet weak var txtEndDate: UITextField!
    let datePicker = UIDatePicker()
    var selectedDate: String?
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var startDateLabel: UILabel!
    @IBOutlet weak var endDateLabel: UILabel!
    @IBOutlet weak var startDateButton: UIButton!
    @IBOutlet weak var endDateButton: UIButton!
    @IBOutlet weak var mainBackView: UIView!
    var startDate = Date()
    var endDate = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtName.delegate = self
        showDatePicker()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true
    }
    
    func showDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        txtStartDate.inputAccessoryView = toolbar
        txtStartDate.inputView = datePicker
        txtEndDate.inputAccessoryView = toolbar
        txtEndDate.inputView = datePicker
    }
    
    @objc func donedatePicker(){
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        if(self.selectedDate == "start"){
            txtStartDate.text = formatter.string(from: datePicker.date)
            startDate = datePicker.date
        }else{
            txtEndDate.text = formatter.string(from: datePicker.date)
            endDate = datePicker.date
        }
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    @IBAction func btnStartDate(_ sender: Any) {
        self.selectedDate = "start"
        self.txtStartDate.becomeFirstResponder()
    }
    
    @IBAction func btnEndDate(_ sender: Any) {
        self.selectedDate = "end"
        self.txtEndDate.becomeFirstResponder()
    }
    
    @IBAction func onAddTrip(_ sender: Any) {
        let db = Firestore.firestore()
        db.collection("trip").addDocument(data: [
            "name": txtName.text!,
            "startDate": startDate,
            "endDate": endDate,
            "tripStatus": "Active"
        ]) { (err) in
            if let err = err {
                print("error",err.localizedDescription)
            } else {
                self.navigationController?.popViewController(animated: true)
                print("Trip added")
            }
        }
    }
    
}
